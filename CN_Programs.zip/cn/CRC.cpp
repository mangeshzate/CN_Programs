
#include <iostream>
#include <string>
using namespace std;

// Perform XOR operation and remove the leading bit
string xorOperation(string a, string b)
{
    string result = "";

    for(int i = 1; i < b.length(); i++)
    {
        if(a[i] == b[i])
            result += '0';
        else
            result += '1';
    }

    return result;
}

// Perform modulo-2 division
string mod2Division(string dividend, string divisor)
{
    int n = divisor.length();

    // Take first n bits of dividend
    string temp = dividend.substr(0, n);

    int position = n;

    // Perform division
    while(position < dividend.length())
    {
        if(temp[0] == '1')
            temp = xorOperation(divisor, temp);
        else
            temp = xorOperation(string(n, '0'), temp);

        // Bring down the next bit
        temp += dividend[position];

        position++;
    }

    // Perform final XOR operation
    if(temp[0] == '1')
        temp = xorOperation(divisor, temp);
    else
        temp = xorOperation(string(n, '0'), temp);

    return temp;
}

int main()
{
    string data, divisor;

    // Enter original data
    cout << "Enter data bits: ";
    cin >> data;

    // Enter generator polynomial
    cout << "Enter generator bits: ";
    cin >> divisor;

    if(divisor.length() < 2)
    {
        cout << "Invalid generator.";
        return 0;
    }

    // Append zeros to the data
    int zeros = divisor.length() - 1;

    string appendedData = data + string(zeros, '0');

    // Calculate CRC remainder
    string remainder = mod2Division(appendedData, divisor);

    // Generate transmitted data
    string transmittedData = data + remainder;

    cout << "\nCRC remainder: " << remainder;
    cout << "\nTransmitted data: " << transmittedData;

    // Enter received data
    string received;

    cout << "\n\nEnter received data: ";
    cin >> received;

    // Check received data using modulo-2 division
    string receivedRemainder = mod2Division(received, divisor);

    cout << "\nReceiver remainder: " << receivedRemainder;

    // Check whether remainder contains any 1
    bool error = false;

    for(int i = 0; i < receivedRemainder.length(); i++)
    {
        if(receivedRemainder[i] == '1')
        {
            error = true;
            break;
        }
    }

    if(error)
        cout << "\nError detected.";
    else
        cout << "\nNo error detected.";

    return 0;
}
