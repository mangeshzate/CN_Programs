
#include <iostream>
using namespace std;

int main() {
    int n, window, i = 1, lost;
    int ack[101] = {0};

    cout << "Enter number of frames: ";
    cin >> n;

    cout << "Enter window size: ";
    cin >> window;

    while (i <= n) {
        cout << "\nSending frames: ";

        for (int j = i; j < i + window && j <= n; j++) {
            cout << j << " ";
        }

        cout << "\nEnter lost frame number (0 if none): ";
        cin >> lost;

        if (lost == 0) {
            for (int j = i; j < i + window && j <= n; j++) {
                ack[j] = 1;
            }

            cout << "All ACKs received successfully!" << endl;
        }
        else if (lost >= i && lost < i + window && lost <= n) {

            for (int j = i; j < i + window && j <= n; j++) {
                if (j != lost) {
                    ack[j] = 1;
                }
            }

            cout << "Frame " << lost << " lost!" << endl;
            cout << "ACK received for other frames." << endl;

            cout << "Retransmitting only Frame " << lost << endl;
            cout << "ACK received for Frame " << lost;

            ack[lost] = 1;
        }
        else {
            cout << "Invalid frame number!" << endl;
            continue;
        }

        i = i + window;
    }

    cout << "\nAll frames acknowledged successfully!" << endl;

    return 0;
}

//improved version


// #include <iostream>
// using namespace std;

// int main() {
//     int n, window, lost;

//     cout << "Enter number of frames: ";
//     cin >> n;

//     cout << "Enter window size: ";
//     cin >> window;

//     if (n < 1 || n > 100 || window < 1 || window > n) {
//         cout << "Invalid input!";
//         return 0;
//     }

//     int ack[101] = {0};

//     int i = 1;

//     while (i <= n) {

//         cout << "\nSending frames: ";

//         for (int j = i; j < i + window && j <= n; j++) {
//             cout << j << " ";
//         }

//         cout << "\nEnter lost frame number (0 if none): ";
//         cin >> lost;

//         while (lost != 0) {

//             if (lost < i || lost >= i + window || lost > n) {
//                 cout << "Invalid frame number!" << endl;
//             }
//             else if (ack[lost] == 1) {
//                 cout << "Frame already acknowledged!" << endl;
//             }
//             else {
//                 cout << "Frame " << lost << " lost!" << endl;

//                 for (int j = i; j < i + window && j <= n; j++) {
//                     if (j != lost) {
//                         ack[j] = 1;
//                     }
//                 }

//                 cout << "Retransmitting only Frame " << lost << endl;
//                 ack[lost] = 1;
//             }

//             cout << "Enter another lost frame (0 if none): ";
//             cin >> lost;
//         }

//         for (int j = i; j < i + window && j <= n; j++) {
//             ack[j] = 1;
//         }

//         cout << "All frames in current window acknowledged!" << endl;

//         i = i + window;
//     }

//     cout << "\nAll frames transmitted successfully!" << endl;

//     return 0;
// }
