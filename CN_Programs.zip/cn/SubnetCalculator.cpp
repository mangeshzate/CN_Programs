#include <iostream>
#include <sstream>
#include <string>
#include <cstdint>
using namespace std;

// Function to convert IP address into integer
uint32_t ipToInt(string ip) {
    stringstream ss(ip);
    string part;
    uint32_t result = 0;
    int count = 0;

    while (getline(ss, part, '.')) {
        if (part.empty() || part.length() > 3)
            return 0;

        for (char c : part) {
            if (c < '0' || c > '9')
                return 0;
        }

        int num = stoi(part);

        if (num < 0 || num > 255)
            return 0;

        result = (result << 8) | num;
        count++;
    }

    if (count != 4)
        return 0;

    return result;
}

// Function to convert integer into IP address
string intToIP(uint32_t ip) {
    return to_string((ip >> 24) & 255) + "." +
           to_string((ip >> 16) & 255) + "." +
           to_string((ip >> 8) & 255) + "." +
           to_string(ip & 255);
}

// Main function
int main() {
    string ip;
    int prefix;

    cout << "Enter IP Address: ";
    cin >> ip;

    uint32_t address = ipToInt(ip);

    if (address == 0 && ip != "0.0.0.0") {
        cout << "Invalid IP Address!" << endl;
        return 0;
    }

    cout << "Enter Prefix Length (0-32): ";
    cin >> prefix;

    if (prefix < 0 || prefix > 32) {
        cout << "Invalid Prefix Length!" << endl;
        return 0;
    }

    // Calculate subnet mask
    uint32_t mask;

    if (prefix == 0)
        mask = 0;
    else
        mask = 0xFFFFFFFF << (32 - prefix);

    // Calculate network and broadcast address
    uint32_t network = address & mask;
    uint32_t broadcast = network | (~mask);

    cout << "\n----- SUBNET DETAILS -----" << endl;

    cout << "IP Address       : " << intToIP(address) << endl;
    cout << "Subnet Mask      : " << intToIP(mask) << endl;
    cout << "Network Address  : " << intToIP(network) << endl;
    cout << "Broadcast Address: " << intToIP(broadcast) << endl;

    // Calculate usable host range
    uint64_t totalHosts = 1ULL << (32 - prefix);

    if (prefix <= 30) {
        cout << "First Usable IP  : "
             << intToIP(network + 1) << endl;

        cout << "Last Usable IP   : "
             << intToIP(broadcast - 1) << endl;

        cout << "Usable Hosts     : "
             << totalHosts - 2 << endl;
    }
    else if (prefix == 31) {
        cout << "First Usable IP  : "
             << intToIP(network) << endl;

        cout << "Last Usable IP   : "
             << intToIP(broadcast) << endl;

        cout << "Usable Hosts     : 2" << endl;
    }
    else {//if prefix ==32 only one ip address
        cout << "First Usable IP  : "
             << intToIP(network) << endl;

        cout << "Last Usable IP   : "
             << intToIP(network) << endl;

        cout << "Usable Hosts     : 1" << endl;
    }

    return 0;
}
