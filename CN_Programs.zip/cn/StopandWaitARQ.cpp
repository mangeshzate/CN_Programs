
#include <iostream>
using namespace std;

int main() {
    int n, i = 1, choice;

    cout << "Enter number of frames: ";
    cin >> n;

    while (i <= n) {
        cout << "\nSending Frame " << i << endl;

        cout << "Did receiver receive the frame? (1 = Yes, 0 = No): ";
        cin >> choice;

        if (choice == 1) {
            cout << "ACK received for Frame " << i << endl;
            i++;
        }
        else if (choice == 0) {
            cout << "Frame " << i << " lost!" << endl;
            cout << "Retransmitting Frame " << i << endl;
        }
        else {
            cout << "Invalid choice! Enter 1 or 0." << endl;
        }
    }

    cout << "\nAll frames transmitted successfully!" << endl;

    return 0;
}
