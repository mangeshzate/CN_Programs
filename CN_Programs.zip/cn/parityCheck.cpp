
#include <iostream>
#include <string>
using namespace std;

int main()
{
    string data, received;
    int count = 0;

    // Enter 7-bit data
    cout << "Enter 7-bit data: ";
    cin >> data;

    if(data.length() != 7)
    {
        cout << "Please enter exactly 7 bits.";
        return 0;
    }

    // Count number of 1s in original data
    for(int i = 0; i < data.length(); i++)
    {
        if(data[i] == '1')
            count++;
    }

    // Generate even parity bit
    char parityBit;

    if(count % 2 == 0)
        parityBit = '0';
    else
        parityBit = '1';

    // Append parity bit to data
    string transmitted = data + parityBit;

    cout << "\nParity bit: " << parityBit;
    cout << "\nTransmitted data: " << transmitted;

    // Enter received data
    cout << "\n\nEnter received 8-bit data: ";
    cin >> received;

    if(received.length() != 8)
    {
        cout << "Please enter exactly 8 bits.";
        return 0;
    }

    count = 0;
    

    // Count number of 1s in received data
    for(int i = 0; i < received.length(); i++)
    {
        if(received[i] == '1')
            count++;
    }

    // Check even parity
    if(count % 2 == 0)
        cout << "\nNo error detected.";
    else
        cout << "\nError detected in received data.";

    return 0;
}
