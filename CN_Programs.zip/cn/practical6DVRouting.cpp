
#include <iostream>
using namespace std;

const int INF = 9999;

int main() {
    int n;

    // Arrays to store network information
    int cost[10][10];       // Direct connection cost
    int dist[10][10];       // Shortest distance
    int nextHop[10][10];    // Next router to reach destination

    // Take number of routers
    cout << "Enter number of routers: ";
    cin >> n;

    // Take cost matrix from user
    cout << "Enter cost matrix (0 for no connection):\n";

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> cost[i][j];

            // Distance from router to itself is 0
            if (i == j)
                cost[i][j] = 0;

            // 0 means no direct connection
            else if (cost[i][j] == 0)
                cost[i][j] = INF;

            // Initially, shortest distance is direct cost
            dist[i][j] = cost[i][j];

            // Initialize next hop
            if (i == j)
                nextHop[i][j] = i;
            else if (cost[i][j] != INF)
                nextHop[i][j] = j;
            else
                nextHop[i][j] = -1;
        }
    }

    // Distance Vector Routing Algorithm
    bool updated;

    do {
        updated = false;

        int oldDist[10][10];

        // Store previous distance table
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                oldDist[i][j] = dist[i][j];
            }
        }

        // Check all source, destination and intermediate routers
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {

                    // Check if i is connected to k
                    // and k can reach j
                    if (cost[i][k] != INF &&
                        oldDist[k][j] != INF) {

                        // Calculate new distance through router k
                        int newDist = cost[i][k] + oldDist[k][j];

                        // Update if new path is shorter
                        if (newDist < dist[i][j]) {
                            dist[i][j] = newDist;

                            // Store next hop
                            nextHop[i][j] = k;

                            updated = true;
                        }
                    }
                }
            }
        }

    } while (updated);  // Repeat until no changes occur

    // Display final routing tables
    cout << "\nDISTANCE VECTOR ROUTING TABLES\n";

    for (int i = 0; i < n; i++) {

        cout << "\nRouter R" << i << ":\n";
        cout << "Destination\tCost\tNext Hop\n";

        for (int j = 0; j < n; j++) {

            cout << "R" << j << "\t\t";

            // Display shortest distance
            if (dist[i][j] == INF)
                cout << "INF\t";
            else
                cout << dist[i][j] << "\t";

            // Display next hop
            if (nextHop[i][j] == -1)
                cout << "-";
            else
                cout << "R" << nextHop[i][j];

            cout << endl;
        }
    }

    return 0;
}
