
#include <iostream>
using namespace std;

int main() {
    int n, window, i = 1, lost;

    // Accept total number of frames
    cout << "Enter number of frames: ";
    cin >> n;

    // Accept window size
    cout << "Enter window size: ";
    cin >> window;

    // Continue until all frames are transmitted
    while (i <= n) {

        cout << "\nSending frames: ";

        // Send frames according to the window size
        for (int j = i; j < i + window && j <= n; j++) {
            cout << j << " ";
        }

        // Check whether any frame is lost
        cout << "\nEnter lost frame number (0 if none): ";
        cin >> lost;

        // If no frame is lost
        if (lost == 0) {
            cout << "All ACKs received successfully!" << endl;

            // Move the window forward
            i = i + window;
        }

        // If a frame is lost in the current window
        else if (lost >= i && lost < i + window && lost <= n) {

            cout << "Frame " << lost << " lost!" << endl;

            // Retransmit the lost frame and subsequent frames
            cout << "Retransmitting from Frame " << lost << endl;

            // Go back to the lost frame
            i = lost;
        }

        // If the entered frame number is invalid
        else {
            cout << "Invalid frame number!" << endl;
        }
    }

    // Display successful transmission message
    cout << "\nAll frames transmitted successfully!" << endl;

    return 0;
}
