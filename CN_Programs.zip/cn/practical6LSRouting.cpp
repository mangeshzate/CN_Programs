//use Dijkstras Algo
#include <iostream>
using namespace std;

const int INF = 9999;

int main() {
    int n;

    // Arrays to store network information
    int graph[10][10];   // Cost matrix of the network
    int dist[10];        // Shortest distance from source
    int visited[10];     // Checks whether router is visited
    int nextHop[10];     // Stores the next router

    // Take number of routers
    cout << "Enter number of routers: ";
    cin >> n;

    // Take cost matrix
    cout << "Enter cost matrix (0 for no connection):\n";

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> graph[i][j];

            // Distance from a router to itself is 0
            if (i == j)
                graph[i][j] = 0;

            // 0 means no direct connection
            else if (graph[i][j] == 0)
                graph[i][j] = INF;
        }
    }

    // Run Dijkstra's algorithm from every router
    for (int src = 0; src < n; src++) {

        // Initialize arrays for current source router
        for (int i = 0; i < n; i++) {
            dist[i] = INF;
            visited[i] = 0;
            nextHop[i] = -1;
        }

        // Distance from source to itself is 0
        dist[src] = 0;
        nextHop[src] = src;

        // Dijkstra's shortest path algorithm
        for (int count = 0; count < n; count++) {

            int u = -1;
            int minDist = INF;

            // Find the unvisited router with minimum distance
            for (int i = 0; i < n; i++) {
                if (!visited[i] && dist[i] < minDist) {
                    minDist = dist[i];
                    u = i;
                }
            }

            // Stop if no reachable router is left
            if (u == -1)
                break;

            // Mark selected router as visited
            visited[u] = 1;

            // Update distances of neighboring routers
            for (int v = 0; v < n; v++) {

                if (!visited[v] &&
                    graph[u][v] != INF &&
                    dist[u] != INF) {

                    // Calculate new distance through router u
                    int newDist = dist[u] + graph[u][v];

                    // Update if new path is shorter
                    if (newDist < dist[v]) {
                        dist[v] = newDist;

                        // Find the first router in the path
                        if (u == src)
                            nextHop[v] = v;
                        else
                            nextHop[v] = nextHop[u];
                    }
                }
            }
        }

        // Display routing table for current source router
        cout << "\nLINK STATE ROUTING TABLE\n";
        cout << "Router R" << src << ":\n";

        cout << "Destination\tCost\tNext Hop\n";

        for (int i = 0; i < n; i++) {
            cout << "R" << i << "\t\t";

            // Display shortest distance
            if (dist[i] == INF)
                cout << "INF\t";
            else
                cout << dist[i] << "\t";

            // Display next hop
            if (nextHop[i] == -1)
                cout << "-";
            else
                cout << "R" << nextHop[i];

            cout << endl;
        }
    }

    return 0;
}
