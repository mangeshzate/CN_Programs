A. Parity Check
Concept: In even parity, an extra parity bit is added so that the total number of 1s becomes even. It detects errors but cannot correct them.

#include <iostream>
#include <string>
using namespace std;

int main() {
    string data;

    cout << "Enter 7-bit data: ";
    cin >> data;

    if (data.length() != 7) {
        cout << "Please enter exactly 7 bits.";
        return 0;
    }

    int count = 0;

    for (char bit : data) {
        if (bit == '1')
            count++;
    }

    char parityBit = (count % 2 == 0) ? '0' : '1';

    string transmitted = data + parityBit;

    cout << "Data bits: " << data << endl;
    cout << "Parity bit: " << parityBit << endl;
    cout << "Transmitted data: " << transmitted << endl;

    string received;
    cout << "Enter received 8-bit data: ";
    cin >> received;

    int receivedCount = 0;

    for (char bit : received) {
        if (bit == '1')
            receivedCount++;
    }

    if (receivedCount % 2 == 0)
        cout << "No single-bit error detected.";
    else
        cout << "Single-bit error detected.";

    return 0;
}



Sample Output:
Enter 7-bit data: 1011001
Data bits: 1011001
Parity bit: 0
Transmitted data: 10110010
Enter received 8-bit data: 10100010
Single-bit error detected.


B. Cyclic Redundancy Check (CRC)
Concept: CRC uses XOR-based binary division to detect errors. The remainder is appended to the original data before transmission.

#include <iostream>
#include <string>
using namespace std;

string xorOperation(string a, string b) {
    string result = "";

    for (int i = 1; i < b.length(); i++) {
        result += (a[i] == b[i]) ? '0' : '1';
    }

    return result;
}

string mod2Division(string dividend, string divisor) {
    int n = divisor.length();
    string temp = dividend.substr(0, n);
    int position = n;

    while (position < dividend.length()) {
        if (temp[0] == '1')
            temp = xorOperation(divisor, temp);
        else
            temp = xorOperation(string(n, '0'), temp);

        temp += dividend[position];
        position++;
    }

    if (temp[0] == '1')
        temp = xorOperation(divisor, temp);
    else
        temp = xorOperation(string(n, '0'), temp);

    return temp;
}

int main() {
    string data, divisor;

    cout << "Enter data bits: ";
    cin >> data;

    cout << "Enter generator bits: ";
    cin >> divisor;

    int zeros = divisor.length() - 1;

    string appendedData = data + string(zeros, '0');

    string remainder = mod2Division(appendedData, divisor);

    string transmittedData = data + remainder;

    cout << "CRC remainder: " << remainder << endl;
    cout << "Transmitted data: " << transmittedData << endl;

    string received;

    cout << "Enter received data: ";
    cin >> received;

    string receivedRemainder = mod2Division(received, divisor);

    cout << "Receiver remainder: " << receivedRemainder << endl;

    bool error = false;

    for (char bit : receivedRemainder) {
        if (bit == '1') {
            error = true;
            break;
        }
    }

    if (error)
        cout << "Error detected.";
    else
        cout << "No error detected.";

    return 0;
}



Sample Output:
Enter data bits: 1101
Enter generator bits: 1011
CRC remainder: 001
Transmitted data: 1101001
Enter received data: 1100001
Receiver remainder: 011
Error detected.


C. Hamming Code
Concept: Hamming Code adds parity bits at positions 1, 2, 4, 8, etc. It uses these bits to identify and correct a single-bit error.

#include <iostream>
using namespace std;

int main() {
    int data[20], hamming[30] = {0};
    int m, r = 0;

    cout << "Enter number of data bits: ";
    cin >> m;

    cout << "Enter data bits: ";
    for (int i = 0; i < m; i++)
        cin >> data[i];

    while ((1 << r) < m + r + 1)
        r++;

    int n = m + r;
    int j = 0;

    // Place data bits
    for (int i = 1; i <= n; i++) {
        if ((i & (i - 1)) != 0)
            hamming[i] = data[j++];
    }

    // Calculate parity bits
    for (int i = 0; i < r; i++) {
        int p = 1 << i;
        int parity = 0;

        for (int k = 1; k <= n; k++) {
            if (k & p)
                parity ^= hamming[k];
        }

        hamming[p] = parity;
    }

    cout << "Generated Hamming code: ";
    for (int i = 1; i <= n; i++)
        cout << hamming[i];

    cout << "\nEnter received Hamming code: ";
    for (int i = 1; i <= n; i++)
        cin >> hamming[i];

    // Detect error
    int errorPosition = 0;

    for (int i = 0; i < r; i++) {
        int p = 1 << i;
        int parity = 0;

        for (int k = 1; k <= n; k++) {
            if (k & p)
                parity ^= hamming[k];
        }

        if (parity)
            errorPosition += p;
    }

    if (errorPosition == 0) {
        cout << "No single-bit error detected.";
    }
    else {
        cout << "Error at position: " << errorPosition << endl;

        hamming[errorPosition] ^= 1;

        cout << "Corrected Hamming code: ";
        for (int i = 1; i <= n; i++)
            cout << hamming[i];
    }

    return 0;
}



Sample Output:
Enter number of data bits: 4
Enter data bits: 1 0 1 1
Generated Hamming code: 0110011
Enter received Hamming code: 0 1 1 0 1 1 1
Error at position: 5
Corrected Hamming code: 0110011