
#include <iostream>
#include <winsock2.h>
#include <string>
using namespace std;

#pragma comment(lib, "ws2_32.lib")

int main()
{
    WSADATA wsa;
    SOCKET serverSocket;
    sockaddr_in server, client;
    char buffer[1024] = {0};

    // Step 1: Initialize Winsock
    WSAStartup(MAKEWORD(2, 2), &wsa);

    // Step 2: Create UDP socket
    serverSocket = socket(AF_INET, SOCK_DGRAM, 0);

    // Step 3: Set server address and port
    server.sin_family = AF_INET;
    server.sin_port = htons(8081);
    server.sin_addr.s_addr = INADDR_ANY;

    // Step 4: Bind socket to IP and port
    bind(serverSocket, (sockaddr*)&server, sizeof(server));

    cout << "UDP Server is waiting for message..." << endl;

    int clientSize = sizeof(client);

    // Step 5: Receive message from client
    int bytesReceived = recvfrom(
        serverSocket, buffer, sizeof(buffer) - 1, 0,
        (sockaddr*)&client, &clientSize
    );

    // Add null character to end the received string
    if (bytesReceived != SOCKET_ERROR)
    {
        buffer[bytesReceived] = '\0';

        cout << "Client: " << buffer << endl;

        // Step 6: Send reply to client
        string msg = "Hello Client! UDP message received.";

        sendto(serverSocket, msg.c_str(), msg.length(), 0,
               (sockaddr*)&client, clientSize);

        cout << "Reply sent to client." << endl;
    }

    // Step 7: Close socket
    closesocket(serverSocket);

    // Step 8: Release Winsock resources
    WSACleanup();

    return 0;
}
