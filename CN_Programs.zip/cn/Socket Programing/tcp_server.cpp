
#include <iostream>
#include <winsock2.h>
#include <string>
using namespace std;

#pragma comment(lib, "ws2_32.lib")

int main()
{
    WSADATA wsa;
    SOCKET serverSocket, clientSocket;
    sockaddr_in server, client;
    char buffer[1024] = {0};

    // Step 1: Initialize Winsock
    WSAStartup(MAKEWORD(2, 2), &wsa);

    // Step 2: Create TCP socket
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);

    // Step 3: Set server address and port
    server.sin_family = AF_INET;
    server.sin_port = htons(8080);
    server.sin_addr.s_addr = INADDR_ANY;

    // Step 4: Bind socket to IP and port
    bind(serverSocket, (sockaddr*)&server, sizeof(server));

    // Step 5: Listen for client connections
    listen(serverSocket, 3);

    cout << "TCP Server is waiting for client..." << endl;

    int clientSize = sizeof(client);

    // Step 6: Accept client connection
    clientSocket = accept(serverSocket,
                          (sockaddr*)&client,
                          &clientSize);

    cout << "Client connected!" << endl;

    // Step 7: Receive message from client
    recv(clientSocket, buffer, sizeof(buffer) - 1, 0);

    cout << "Client: " << buffer << endl;

    // Step 8: Send reply to client
    string msg = "Hello Client! Message received.";

    send(clientSocket, msg.c_str(), msg.length(), 0);

    cout << "Message sent to client." << endl;

    // Step 9: Close sockets
    closesocket(clientSocket);
    closesocket(serverSocket);

    // Step 10: Release Winsock resources
    WSACleanup();

    return 0;
}
