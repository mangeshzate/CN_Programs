
#include <iostream>
#include <winsock2.h>
#include <string>
using namespace std;

#pragma comment(lib, "ws2_32.lib")

int main()
{
    WSADATA wsa;
    SOCKET clientSocket;
    sockaddr_in server;
    char buffer[1024] = {0};

    // Step 1: Initialize Winsock
    WSAStartup(MAKEWORD(2, 2), &wsa);

    // Step 2: Create TCP socket
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);

    // Step 3: Set server IP address and port
    server.sin_family = AF_INET;
    server.sin_port = htons(8080);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Step 4: Connect to the server
    connect(clientSocket, (sockaddr*)&server, sizeof(server));

    cout << "Connected to TCP Server!" << endl;

    // Step 5: Send message to server
    string msg = "Hello Server!";

    send(clientSocket, msg.c_str(), msg.length(), 0);

    cout << "Message sent to server." << endl;

    // Step 6: Receive reply from server
    recv(clientSocket, buffer, sizeof(buffer) - 1, 0);

    cout << "Server: " << buffer << endl;

    // Step 7: Close socket
    closesocket(clientSocket);

    // Step 8: Release Winsock resources
    WSACleanup();

    return 0;
}
