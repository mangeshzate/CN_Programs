
#include <iostream>
#include <winsock2.h>
#include <string>
using namespace std;

#pragma comment(lib, "ws2_32.lib")

int main()
{
    WSADATA wsa;
    SOCKET clientSocket;
    sockaddr_in server;
    char buffer[1024] = {0};

    // Step 1: Initialize Winsock
    WSAStartup(MAKEWORD(2, 2), &wsa);

    // Step 2: Create UDP socket
    clientSocket = socket(AF_INET, SOCK_DGRAM, 0);

    // Step 3: Set server IP address and port
    server.sin_family = AF_INET;
    server.sin_port = htons(8081);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Step 4: Send message to server
    string msg = "Hello UDP Server!";

    sendto(clientSocket, msg.c_str(), msg.length(), 0,
           (sockaddr*)&server, sizeof(server));

    cout << "Message sent to UDP Server." << endl;

    // Step 5: Receive reply from server
    int serverSize = sizeof(server);

    int bytesReceived = recvfrom(
        clientSocket, buffer, sizeof(buffer) - 1, 0,
        (sockaddr*)&server, &serverSize
    );

    // Add null character to end the received string
    if (bytesReceived != SOCKET_ERROR)
    {
        buffer[bytesReceived] = '\0';

        cout << "Server: " << buffer << endl;
    }

    // Step 6: Close socket
    closesocket(clientSocket);

    // Step 7: Release Winsock resources
    WSACleanup();

    return 0;
}
